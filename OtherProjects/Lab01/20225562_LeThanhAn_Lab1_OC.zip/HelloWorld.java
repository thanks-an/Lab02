//Example 1: HelloWorld.java 20225562
//Text-printing program 
public class HelloWorld{
       public static void main(String args[]){ 
            System.out.println("Xin chao \ncac ban!"); 
            System.out.println("Hello \tworld!");}
} //end of method main